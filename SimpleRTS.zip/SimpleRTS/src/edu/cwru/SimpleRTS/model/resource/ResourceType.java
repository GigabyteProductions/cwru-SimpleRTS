package edu.cwru.SimpleRTS.model.resource;

public enum ResourceType {
	GOLD,
	WOOD
}
