package edu.cwru.SimpleRTS.model.unit;

public enum UnitTask {
	Wood,
	Gold,
	Idle,
	Build,
	Move,
	Attack,
}
